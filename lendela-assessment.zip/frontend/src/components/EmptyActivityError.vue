<script setup></script>

<template>
    <p class="errorMessage">Activity input text box cannot be empty!</p>
</template>

<style scoped>
.errorMessage {
    font-size: medium;
    color: orange;
    text-align: center;
}
</style>
